<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-location-country" only-nested=true}}
{{html name="country"}}
