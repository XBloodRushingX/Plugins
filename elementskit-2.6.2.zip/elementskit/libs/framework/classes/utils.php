<?php 
namespace ElementsKit\Libs\Framework\Classes;
defined( 'ABSPATH' ) || exit;

class Utils extends \ElementsKit_Lite\Libs\Framework\Classes\Utils{

}